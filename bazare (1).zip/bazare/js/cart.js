/* ============================================================
   BAZARE — Cart System (cart.js)
   ============================================================ */

// ── Cart State (localStorage) ──
function getCart() {
  try {
    return JSON.parse(localStorage.getItem('bazare_cart') || '[]');
  } catch { return []; }
}

function saveCart(cart) {
  localStorage.setItem('bazare_cart', JSON.stringify(cart));
  updateCartBadge();
}

// ── Add to Cart ──
function addToCart(product, triggerBtn = null) {
  requireAuth(() => {
    const cart = getCart();
    const existing = cart.find(i => i.id === product.id);

    if (existing) {
      existing.qty = (existing.qty || 1) + 1;
    } else {
      cart.push({ ...product, qty: 1 });
    }

    saveCart(cart);

    if (triggerBtn) {
      triggerBtn.textContent = '✓ যোগ হয়েছে';
      triggerBtn.classList.add('added');
      setTimeout(() => {
        triggerBtn.textContent = '+ কার্ট';
        triggerBtn.classList.remove('added');
      }, 1500);
    }

    showToast(`🛒 "${product.name}" কার্টে যোগ হয়েছে`, 'success');
    updateCartBadge();
  });
}

// ── Remove from Cart ──
function removeFromCart(productId) {
  const cart = getCart().filter(i => i.id !== productId);
  saveCart(cart);
}

// ── Update Quantity ──
function updateQty(productId, qty) {
  const cart = getCart();
  const item = cart.find(i => i.id === productId);
  if (item) {
    if (qty <= 0) removeFromCart(productId);
    else { item.qty = qty; saveCart(cart); }
  }
}

// ── Cart Total ──
function getCartTotal() {
  return getCart().reduce((sum, i) => sum + (i.price * (i.qty || 1)), 0);
}

function getCartCount() {
  return getCart().reduce((sum, i) => sum + (i.qty || 1), 0);
}

// ── Update Badge ──
function updateCartBadge() {
  const count = getCartCount();
  document.querySelectorAll('.cart-badge').forEach(el => {
    el.textContent = count;
    el.style.display = count > 0 ? 'flex' : 'none';
  });
}

// ── Init ──
document.addEventListener('DOMContentLoaded', updateCartBadge);
