/* ============================================================
   BAZARE — Firebase Init (firebase.js)
   ============================================================ */

// Firebase SDKs are loaded via CDN in each HTML file.
// This file runs after they load.

const firebaseConfig = {
  apiKey:            "YOUR_API_KEY",
  authDomain:        "YOUR_PROJECT.firebaseapp.com",
  projectId:         "YOUR_PROJECT_ID",
  storageBucket:     "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId:             "YOUR_APP_ID"
};

// Initialize only once
if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

const auth = firebase.auth();
const db   = firebase.firestore();

// Init auth listeners
if (typeof initAuth === 'function') initAuth();
