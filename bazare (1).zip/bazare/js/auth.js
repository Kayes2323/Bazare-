/* ============================================================
   BAZARE — Auth System (auth.js)
   Handles login popup, Google, Facebook, Phone OTP
   ============================================================ */

// ── Firebase Config ──
// Replace with your actual Firebase project config
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// ── Auth State ──
let currentUser = null;
let pendingAction = null; // what to do after login
let recaptchaVerifier = null;
let confirmationResult = null;

// ── Initialize Firebase (called from firebase.js) ──
function initAuth() {
  firebase.auth().onAuthStateChanged((user) => {
    currentUser = user;
    updateNavUI(user);
    if (user && pendingAction) {
      pendingAction();
      pendingAction = null;
    }
  });
}

// ── Update navbar based on auth state ──
function updateNavUI(user) {
  const loginBtn  = document.getElementById('nav-login-btn');
  const userMenu  = document.getElementById('nav-user-menu');
  const userNameEl = document.getElementById('nav-user-name');
  const userAvatarEl = document.getElementById('nav-user-avatar');

  if (!loginBtn || !userMenu) return;

  if (user) {
    loginBtn.style.display  = 'none';
    userMenu.style.display  = 'flex';
    if (userNameEl) {
      const name = user.displayName ? user.displayName.split(' ')[0] : 'আপনি';
      userNameEl.textContent = name;
    }
    if (userAvatarEl && user.photoURL) {
      userAvatarEl.innerHTML = `<img src="${user.photoURL}" alt="avatar">`;
    } else if (userAvatarEl && user.displayName) {
      userAvatarEl.textContent = user.displayName[0].toUpperCase();
    }
  } else {
    loginBtn.style.display  = 'flex';
    userMenu.style.display  = 'none';
  }
}

// ── Guard: require login before action ──
function requireAuth(action) {
  if (currentUser) {
    action();
  } else {
    pendingAction = action;
    showAuthModal('আপনার একটি কাজ সম্পন্ন করতে লগইন প্রয়োজন');
  }
}

// ── Show Auth Modal ──
function showAuthModal(hint = '') {
  const modal = document.getElementById('auth-modal');
  if (!modal) return;

  // Reset to main view
  showAuthStep('main');

  if (hint) {
    const hintEl = document.getElementById('auth-hint');
    if (hintEl) hintEl.textContent = hint;
  }

  modal.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function hideAuthModal() {
  const modal = document.getElementById('auth-modal');
  if (!modal) return;
  modal.classList.add('hidden');
  document.body.style.overflow = '';
  pendingAction = null;
}

function showAuthStep(step) {
  // steps: 'main', 'phone-enter', 'phone-otp'
  document.querySelectorAll('.auth-step').forEach(el => {
    el.classList.add('hidden');
  });
  const el = document.getElementById(`auth-step-${step}`);
  if (el) el.classList.remove('hidden');
}

// ── Google Login ──
async function loginWithGoogle() {
  try {
    const provider = new firebase.auth.GoogleAuthProvider();
    provider.addScope('profile');
    provider.addScope('email');
    await firebase.auth().signInWithPopup(provider);
    hideAuthModal();
    showToast('✅ Google দিয়ে লগইন সফল!', 'success');
  } catch (err) {
    console.error('Google login error:', err);
    showToast('❌ লগইন ব্যর্থ হয়েছে', 'error');
  }
}

// ── Facebook Login ──
async function loginWithFacebook() {
  try {
    const provider = new firebase.auth.FacebookAuthProvider();
    provider.addScope('public_profile');
    provider.addScope('email');
    await firebase.auth().signInWithPopup(provider);
    hideAuthModal();
    showToast('✅ Facebook দিয়ে লগইন সফল!', 'success');
  } catch (err) {
    console.error('Facebook login error:', err);
    showToast('❌ লগইন ব্যর্থ হয়েছে। Facebook app সেটআপ দেখুন।', 'error');
  }
}

// ── Phone Login — Step 1: Send OTP ──
async function sendOTP() {
  const phoneInput = document.getElementById('phone-input');
  const sendBtn    = document.getElementById('send-otp-btn');
  if (!phoneInput) return;

  let phone = phoneInput.value.trim();

  // Auto-add Bangladesh code
  if (phone.startsWith('0')) phone = '+88' + phone;
  if (!phone.startsWith('+')) phone = '+88' + phone;

  if (phone.length < 13) {
    showToast('সঠিক ফোন নম্বর দিন', 'error');
    return;
  }

  try {
    sendBtn.classList.add('loading');
    sendBtn.textContent = '';

    // reCAPTCHA (invisible)
    if (!recaptchaVerifier) {
      recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container', {
        size: 'invisible',
        callback: () => {}
      });
    }

    confirmationResult = await firebase.auth().signInWithPhoneNumber(phone, recaptchaVerifier);
    showAuthStep('phone-otp');

    const sentToEl = document.getElementById('otp-sent-to');
    if (sentToEl) sentToEl.textContent = phone;

    // Auto-focus first OTP input
    const firstOtp = document.querySelector('.otp-input');
    if (firstOtp) firstOtp.focus();

    showToast('📱 OTP পাঠানো হয়েছে!', 'success');
  } catch (err) {
    console.error('OTP send error:', err);
    showToast('❌ OTP পাঠাতে ব্যর্থ। নম্বর চেক করুন।', 'error');
  } finally {
    if (sendBtn) {
      sendBtn.classList.remove('loading');
      sendBtn.textContent = 'OTP পাঠান';
    }
  }
}

// ── Phone Login — Step 2: Verify OTP ──
async function verifyOTP() {
  const inputs  = document.querySelectorAll('.otp-input');
  const verifyBtn = document.getElementById('verify-otp-btn');
  const otp = Array.from(inputs).map(i => i.value).join('');

  if (otp.length !== 6) {
    showToast('৬ সংখ্যার OTP দিন', 'error');
    return;
  }

  try {
    verifyBtn.classList.add('loading');
    verifyBtn.textContent = '';
    await confirmationResult.confirm(otp);
    hideAuthModal();
    showToast('✅ ফোন নম্বর দিয়ে লগইন সফল!', 'success');
  } catch (err) {
    console.error('OTP verify error:', err);
    showToast('❌ OTP ভুল। আবার চেষ্টা করুন।', 'error');
    inputs.forEach(i => { i.value = ''; i.classList.add('error'); });
    inputs[0].focus();
  } finally {
    if (verifyBtn) {
      verifyBtn.classList.remove('loading');
      verifyBtn.textContent = 'নিশ্চিত করুন';
    }
  }
}

// ── OTP Input: auto-advance ──
function setupOTPInputs() {
  const inputs = document.querySelectorAll('.otp-input');
  inputs.forEach((input, idx) => {
    input.addEventListener('input', (e) => {
      input.classList.remove('error');
      const val = e.target.value.replace(/\D/g, '');
      input.value = val.slice(-1);
      if (val && idx < inputs.length - 1) {
        inputs[idx + 1].focus();
      }
    });
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace' && !input.value && idx > 0) {
        inputs[idx - 1].focus();
      }
    });
    input.addEventListener('paste', (e) => {
      e.preventDefault();
      const pasted = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g,'');
      inputs.forEach((inp, i) => { inp.value = pasted[i] || ''; });
      if (pasted.length >= 6) inputs[5].focus();
    });
  });
}

// ── Logout ──
async function logout() {
  try {
    await firebase.auth().signOut();
    showToast('লগআউট সফল', 'info');
    // Redirect to homepage if on protected page
    if (window.location.pathname.includes('orders') ||
        window.location.pathname.includes('checkout')) {
      window.location.href = 'index.html';
    }
  } catch (err) {
    console.error('Logout error:', err);
  }
}

// ── Toast helper ──
function showToast(msg, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = msg;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// ── Close modal on backdrop click ──
document.addEventListener('DOMContentLoaded', () => {
  const backdrop = document.getElementById('auth-modal');
  if (backdrop) {
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) hideAuthModal();
    });
  }
  setupOTPInputs();
});
